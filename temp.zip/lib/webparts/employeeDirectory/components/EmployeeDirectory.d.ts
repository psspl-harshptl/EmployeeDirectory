import * as React from 'react';
import type { IEmployeeDirectoryProps } from './IEmployeeDirectoryProps';
declare const EmployeeDirectory: React.FC<IEmployeeDirectoryProps>;
export default EmployeeDirectory;
//# sourceMappingURL=EmployeeDirectory.d.ts.map