import type { IEmployeeFilters } from '../../models/IEmployeeFilters';
export interface IEmployeeFilterBarProps {
    filters: IEmployeeFilters;
    departmentChoices: string[];
    onFiltersChange: (filters: IEmployeeFilters) => void;
}
//# sourceMappingURL=IEmployeeFilterBarProps.d.ts.map