import * as React from 'react';
import type { IEmployeeFilterBarProps } from './IEmployeeFilterBarProps';
declare const EmployeeFilterBar: React.FC<IEmployeeFilterBarProps>;
export default EmployeeFilterBar;
//# sourceMappingURL=EmployeeFilterBar.d.ts.map