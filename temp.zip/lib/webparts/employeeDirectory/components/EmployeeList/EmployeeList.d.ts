import * as React from 'react';
import type { IEmployeeListProps } from './IEmployeeListProps';
declare const EmployeeList: React.FC<IEmployeeListProps>;
export default EmployeeList;
//# sourceMappingURL=EmployeeList.d.ts.map