import * as React from 'react';
import type { IStatusConfirmDialogProps } from './IStatusConfirmDialogProps';
declare const StatusConfirmDialog: React.FC<IStatusConfirmDialogProps>;
export default StatusConfirmDialog;
//# sourceMappingURL=StatusConfirmDialog.d.ts.map