import * as React from 'react';
import type { IEmployeeFormProps } from './IEmployeeFormProps';
declare const EmployeeForm: React.FC<IEmployeeFormProps>;
export default EmployeeForm;
//# sourceMappingURL=EmployeeForm.d.ts.map