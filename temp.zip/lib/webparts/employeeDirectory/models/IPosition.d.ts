export interface IPosition {
    id: number;
    title: string;
}
//# sourceMappingURL=IPosition.d.ts.map