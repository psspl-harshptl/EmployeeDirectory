import type { IEmployeeFilters } from '../models/IEmployeeFilters';
import type { IEmployeeFormData } from '../models/IEmployeeFormData';
import type { IEmployeeSort } from '../models/IEmployeeSort';
export declare const LIST_TITLES: {
    readonly Employee: "Employee";
    readonly Positions: "Positions";
};
export declare const EMPLOYEE_FIELDS: {
    readonly Id: "Id";
    readonly EmpId: "Title";
    readonly User: "User";
    readonly Department: "Department";
    readonly Designation: "Designation";
    readonly MobileNo: "MobileNo";
    readonly Address: "Address";
    readonly DOB: "DOB";
    readonly DOJ: "DOJ";
    readonly IsActive: "IsActive";
};
export declare const POSITION_FIELDS: {
    readonly Id: "Id";
    readonly Title: "Title";
};
export declare const EMPTY_EMPLOYEE_FORM: IEmployeeFormData;
export declare const DEFAULT_FILTERS: IEmployeeFilters;
export declare const DEFAULT_SORT: IEmployeeSort;
//# sourceMappingURL=Constants.d.ts.map