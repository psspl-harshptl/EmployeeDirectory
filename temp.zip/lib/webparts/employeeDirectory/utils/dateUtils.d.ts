/**
 * Converts an ISO date string returned by SharePoint REST into a Date.
 * Returns undefined for empty or invalid values.
 */
export declare function parseSPDate(value: string | null | undefined): Date | undefined;
/**
 * Number of full years between `from` and `to` (default: today).
 * Used for Age (from DOB) and Joined Years (from DOJ). Calculated here instead of
 * relying on the list's calculated columns, which only refresh when an item is saved.
 */
export declare function getCompletedYears(from: Date | undefined, to?: Date): number | undefined;
/**
 * Converts a picked date into the value written to a SharePoint "Date Only" column.
 * The time is reset to local midnight before converting to UTC. This mirrors how SharePoint's
 * own forms store dates and how parseSPDate reads them back, so a date round-trips unchanged
 * as long as the browser and the site regional settings use the same time zone.
 */
export declare function toSPDateValue(date: Date | undefined): string | undefined;
/**
 * Returns the date with the time removed, for day-level comparisons.
 */
export declare function startOfDay(date: Date): Date;
/**
 * Formats a date as e.g. "15 Mar 1995" using the browser locale.
 */
export declare function formatDate(date: Date | undefined): string;
//# sourceMappingURL=dateUtils.d.ts.map