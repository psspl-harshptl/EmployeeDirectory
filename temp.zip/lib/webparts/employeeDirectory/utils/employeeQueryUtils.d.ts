import type { IEmployee } from '../models/IEmployee';
import type { IEmployeeFilters } from '../models/IEmployeeFilters';
import type { IEmployeeSort } from '../models/IEmployeeSort';
export declare function filterEmployees(employees: IEmployee[], filters: IEmployeeFilters): IEmployee[];
/**
 * Returns a sorted copy; the input array is never mutated.
 * Empty values are always placed last, regardless of direction.
 */
export declare function sortEmployees(employees: IEmployee[], sort: IEmployeeSort): IEmployee[];
//# sourceMappingURL=employeeQueryUtils.d.ts.map