import type { IEmployeeFormData } from '../models/IEmployeeFormData';
export type EmployeeFormErrors = Partial<Record<keyof IEmployeeFormData, string>>;
/**
 * Validates the New/Edit Employee form. Returns an empty object when the form is valid.
 * IsActive is not validated: unchecked is a valid answer, so a checkbox cannot be "required".
 */
export declare function validateEmployeeForm(data: IEmployeeFormData, today?: Date): EmployeeFormErrors;
//# sourceMappingURL=employeeValidation.d.ts.map