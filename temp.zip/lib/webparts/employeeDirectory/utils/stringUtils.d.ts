/**
 * Replaces {0}, {1}, ... placeholders in a localized string with the given values.
 */
export declare function formatString(template: string, ...values: (string | number)[]): string;
//# sourceMappingURL=stringUtils.d.ts.map