import type { SPFI } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import type { IEmployee } from '../models/IEmployee';
import type { IEmployeeFormData } from '../models/IEmployeeFormData';
import type { IPosition } from '../models/IPosition';
export declare class EmployeeService {
    private readonly _sp;
    constructor(sp: SPFI);
    getEmployees(): Promise<IEmployee[]>;
    getDepartmentChoices(): Promise<string[]>;
    getPositions(): Promise<IPosition[]>;
    addEmployee(data: IEmployeeFormData): Promise<void>;
    updateEmployee(id: number, data: IEmployeeFormData): Promise<void>;
    setEmployeeActive(id: number, isActive: boolean): Promise<void>;
    private _mapToListItem;
    private _mapEmployee;
}
//# sourceMappingURL=EmployeeService.d.ts.map