declare interface IStyles {
  employeeDirectory: string;
}
declare const styles: IStyles;
export default styles;