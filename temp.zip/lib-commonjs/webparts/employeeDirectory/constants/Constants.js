"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_SORT = exports.DEFAULT_FILTERS = exports.EMPTY_EMPLOYEE_FORM = exports.POSITION_FIELDS = exports.EMPLOYEE_FIELDS = exports.LIST_TITLES = void 0;
exports.LIST_TITLES = {
    Employee: 'Employee',
    Positions: 'Positions'
};
// Internal names of the Employee list columns (verified from List Settings).
// EmpID was created by renaming the OOTB Title column, so its internal name is still "Title".
exports.EMPLOYEE_FIELDS = {
    Id: 'Id',
    EmpId: 'Title',
    User: 'User',
    Department: 'Department',
    Designation: 'Designation',
    MobileNo: 'MobileNo',
    Address: 'Address',
    DOB: 'DOB',
    DOJ: 'DOJ',
    IsActive: 'IsActive'
};
exports.POSITION_FIELDS = {
    Id: 'Id',
    Title: 'Title'
};
exports.EMPTY_EMPLOYEE_FORM = {
    empId: '',
    userId: undefined,
    userEmail: '',
    department: '',
    designationId: undefined,
    mobileNo: '',
    address: '',
    dob: undefined,
    doj: undefined,
    isActive: true
};
// Also applied when filters/sorting are hidden from the property pane,
// so the directory always falls back to showing active employees by Employee ID.
exports.DEFAULT_FILTERS = {
    department: '',
    status: 'active'
};
exports.DEFAULT_SORT = {
    field: 'empId',
    isDescending: false
};
//# sourceMappingURL=Constants.js.map