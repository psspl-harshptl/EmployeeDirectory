"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatString = formatString;
/**
 * Replaces {0}, {1}, ... placeholders in a localized string with the given values.
 */
function formatString(template) {
    var values = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        values[_i - 1] = arguments[_i];
    }
    return template.replace(/\{(\d+)\}/g, function (match, index) {
        var value = values[Number(index)];
        return value !== undefined ? String(value) : match;
    });
}
//# sourceMappingURL=stringUtils.js.map