"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseSPDate = parseSPDate;
exports.getCompletedYears = getCompletedYears;
exports.toSPDateValue = toSPDateValue;
exports.startOfDay = startOfDay;
exports.formatDate = formatDate;
/**
 * Converts an ISO date string returned by SharePoint REST into a Date.
 * Returns undefined for empty or invalid values.
 */
// eslint-disable-next-line @rushstack/no-new-null -- SharePoint REST returns null for empty date fields
function parseSPDate(value) {
    if (!value) {
        return undefined;
    }
    var date = new Date(value);
    return isNaN(date.getTime()) ? undefined : date;
}
/**
 * Number of full years between `from` and `to` (default: today).
 * Used for Age (from DOB) and Joined Years (from DOJ). Calculated here instead of
 * relying on the list's calculated columns, which only refresh when an item is saved.
 */
function getCompletedYears(from, to) {
    if (to === void 0) { to = new Date(); }
    if (!from) {
        return undefined;
    }
    var years = to.getFullYear() - from.getFullYear();
    var anniversaryNotReached = to.getMonth() < from.getMonth() ||
        (to.getMonth() === from.getMonth() && to.getDate() < from.getDate());
    if (anniversaryNotReached) {
        years--;
    }
    return Math.max(years, 0);
}
/**
 * Converts a picked date into the value written to a SharePoint "Date Only" column.
 * The time is reset to local midnight before converting to UTC. This mirrors how SharePoint's
 * own forms store dates and how parseSPDate reads them back, so a date round-trips unchanged
 * as long as the browser and the site regional settings use the same time zone.
 */
function toSPDateValue(date) {
    if (!date) {
        return undefined;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate()).toISOString();
}
/**
 * Returns the date with the time removed, for day-level comparisons.
 */
function startOfDay(date) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}
/**
 * Formats a date as e.g. "15 Mar 1995" using the browser locale.
 */
function formatDate(date) {
    if (!date) {
        return '';
    }
    return date.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' });
}
//# sourceMappingURL=dateUtils.js.map