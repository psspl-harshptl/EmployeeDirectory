"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateEmployeeForm = validateEmployeeForm;
var tslib_1 = require("tslib");
var strings = tslib_1.__importStar(require("EmployeeDirectoryWebPartStrings"));
var dateUtils_1 = require("./dateUtils");
var MOBILE_NUMBER_PATTERN = /^\d{10}$/;
/**
 * Validates the New/Edit Employee form. Returns an empty object when the form is valid.
 * IsActive is not validated: unchecked is a valid answer, so a checkbox cannot be "required".
 */
function validateEmployeeForm(data, today) {
    if (today === void 0) { today = new Date(); }
    var errors = {};
    var todayStart = (0, dateUtils_1.startOfDay)(today);
    if (!data.empId.trim()) {
        errors.empId = strings.RequiredFieldError;
    }
    if (data.userId === undefined) {
        errors.userId = strings.RequiredFieldError;
    }
    if (!data.department) {
        errors.department = strings.RequiredFieldError;
    }
    if (data.designationId === undefined) {
        errors.designationId = strings.RequiredFieldError;
    }
    if (!data.mobileNo.trim()) {
        errors.mobileNo = strings.RequiredFieldError;
    }
    else if (!MOBILE_NUMBER_PATTERN.test(data.mobileNo.trim())) {
        errors.mobileNo = strings.InvalidMobileNoError;
    }
    if (!data.address.trim()) {
        errors.address = strings.RequiredFieldError;
    }
    if (!data.dob) {
        errors.dob = strings.RequiredFieldError;
    }
    else if ((0, dateUtils_1.startOfDay)(data.dob) > todayStart) {
        errors.dob = strings.FutureDateError;
    }
    if (!data.doj) {
        errors.doj = strings.RequiredFieldError;
    }
    else if ((0, dateUtils_1.startOfDay)(data.doj) > todayStart) {
        errors.doj = strings.FutureDateError;
    }
    else if (data.dob && (0, dateUtils_1.startOfDay)(data.doj) <= (0, dateUtils_1.startOfDay)(data.dob)) {
        errors.doj = strings.DojBeforeDobError;
    }
    return errors;
}
//# sourceMappingURL=employeeValidation.js.map