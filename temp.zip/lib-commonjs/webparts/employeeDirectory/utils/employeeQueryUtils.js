"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.filterEmployees = filterEmployees;
exports.sortEmployees = sortEmployees;
var tslib_1 = require("tslib");
function filterEmployees(employees, filters) {
    return employees.filter(function (employee) {
        if (filters.status === 'active' && !employee.isActive) {
            return false;
        }
        if (filters.status === 'inactive' && employee.isActive) {
            return false;
        }
        if (filters.department && employee.department !== filters.department) {
            return false;
        }
        return true;
    });
}
/**
 * Returns a sorted copy; the input array is never mutated.
 * Empty values are always placed last, regardless of direction.
 */
function sortEmployees(employees, sort) {
    var direction = sort.isDescending ? -1 : 1;
    return tslib_1.__spreadArray([], employees, true).sort(function (a, b) {
        var valueA = a[sort.field];
        var valueB = b[sort.field];
        var isEmptyA = valueA === undefined || valueA === '';
        var isEmptyB = valueB === undefined || valueB === '';
        if (isEmptyA || isEmptyB) {
            return Number(isEmptyA) - Number(isEmptyB);
        }
        if (valueA instanceof Date && valueB instanceof Date) {
            return (valueA.getTime() - valueB.getTime()) * direction;
        }
        return String(valueA).localeCompare(String(valueB), undefined, { numeric: true, sensitivity: 'base' }) * direction;
    });
}
//# sourceMappingURL=employeeQueryUtils.js.map