"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeeService = void 0;
var tslib_1 = require("tslib");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/fields");
var Constants_1 = require("../constants/Constants");
var dateUtils_1 = require("../utils/dateUtils");
/* eslint-enable @rushstack/no-new-null */
var EmployeeService = /** @class */ (function () {
    function EmployeeService(sp) {
        this._sp = sp;
    }
    EmployeeService.prototype.getEmployees = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var f, items;
            var _this = this;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        f = Constants_1.EMPLOYEE_FIELDS;
                        return [4 /*yield*/, this._sp.web.lists
                                .getByTitle(Constants_1.LIST_TITLES.Employee)
                                .items.select(f.Id, f.EmpId, f.Department, f.MobileNo, f.Address, f.DOB, f.DOJ, f.IsActive, "".concat(f.User, "/Id"), "".concat(f.User, "/Title"), "".concat(f.User, "/EMail"), "".concat(f.Designation, "/Id"), "".concat(f.Designation, "/Title"))
                                .expand(f.User, f.Designation)
                                .orderBy(f.EmpId, true)
                                .top(5000)()];
                    case 1:
                        items = _a.sent();
                        return [2 /*return*/, items.map(function (item) { return _this._mapEmployee(item); })];
                }
            });
        });
    };
    EmployeeService.prototype.getDepartmentChoices = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var field;
            var _a;
            return tslib_1.__generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this._sp.web.lists
                            .getByTitle(Constants_1.LIST_TITLES.Employee)
                            .fields.getByInternalNameOrTitle(Constants_1.EMPLOYEE_FIELDS.Department)
                            .select('Choices')()];
                    case 1:
                        field = _b.sent();
                        return [2 /*return*/, (_a = field.Choices) !== null && _a !== void 0 ? _a : []];
                }
            });
        });
    };
    EmployeeService.prototype.getPositions = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._sp.web.lists
                            .getByTitle(Constants_1.LIST_TITLES.Positions)
                            .items.select(Constants_1.POSITION_FIELDS.Id, Constants_1.POSITION_FIELDS.Title)
                            .orderBy(Constants_1.POSITION_FIELDS.Title, true)
                            .top(5000)()];
                    case 1:
                        items = _a.sent();
                        return [2 /*return*/, items.map(function (item) { return ({ id: item.Id, title: item.Title }); })];
                }
            });
        });
    };
    EmployeeService.prototype.addEmployee = function (data) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._sp.web.lists
                            .getByTitle(Constants_1.LIST_TITLES.Employee)
                            .items.add(this._mapToListItem(data))];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EmployeeService.prototype.updateEmployee = function (id, data) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._sp.web.lists
                            .getByTitle(Constants_1.LIST_TITLES.Employee)
                            .items.getById(id)
                            .update(this._mapToListItem(data))];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EmployeeService.prototype.setEmployeeActive = function (id, isActive) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var _a;
            return tslib_1.__generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this._sp.web.lists
                            .getByTitle(Constants_1.LIST_TITLES.Employee)
                            .items.getById(id)
                            .update((_a = {}, _a[Constants_1.EMPLOYEE_FIELDS.IsActive] = isActive, _a))];
                    case 1:
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EmployeeService.prototype._mapToListItem = function (data) {
        var _a;
        var f = Constants_1.EMPLOYEE_FIELDS;
        return _a = {},
            _a[f.EmpId] = data.empId.trim(),
            _a["".concat(f.User, "Id")] = data.userId,
            _a[f.Department] = data.department,
            _a["".concat(f.Designation, "Id")] = data.designationId,
            _a[f.MobileNo] = Number(data.mobileNo),
            _a[f.Address] = data.address.trim(),
            _a[f.DOB] = (0, dateUtils_1.toSPDateValue)(data.dob),
            _a[f.DOJ] = (0, dateUtils_1.toSPDateValue)(data.doj),
            _a[f.IsActive] = data.isActive,
            _a;
    };
    EmployeeService.prototype._mapEmployee = function (item) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
        return {
            id: item.Id,
            empId: (_a = item.Title) !== null && _a !== void 0 ? _a : '',
            userId: (_b = item.User) === null || _b === void 0 ? void 0 : _b.Id,
            userTitle: (_d = (_c = item.User) === null || _c === void 0 ? void 0 : _c.Title) !== null && _d !== void 0 ? _d : '',
            userEmail: (_f = (_e = item.User) === null || _e === void 0 ? void 0 : _e.EMail) !== null && _f !== void 0 ? _f : '',
            department: (_g = item.Department) !== null && _g !== void 0 ? _g : '',
            designationId: (_h = item.Designation) === null || _h === void 0 ? void 0 : _h.Id,
            designationTitle: (_k = (_j = item.Designation) === null || _j === void 0 ? void 0 : _j.Title) !== null && _k !== void 0 ? _k : '',
            mobileNo: item.MobileNo !== null ? String(item.MobileNo) : '',
            address: (_l = item.Address) !== null && _l !== void 0 ? _l : '',
            dob: (0, dateUtils_1.parseSPDate)(item.DOB),
            doj: (0, dateUtils_1.parseSPDate)(item.DOJ),
            isActive: item.IsActive === true
        };
    };
    return EmployeeService;
}());
exports.EmployeeService = EmployeeService;
//# sourceMappingURL=EmployeeService.js.map