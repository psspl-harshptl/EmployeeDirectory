"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var ReactDom = tslib_1.__importStar(require("react-dom"));
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_property_pane_1 = require("@microsoft/sp-property-pane");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var sp_1 = require("@pnp/sp");
var strings = tslib_1.__importStar(require("EmployeeDirectoryWebPartStrings"));
var EmployeeDirectory_1 = tslib_1.__importDefault(require("./components/EmployeeDirectory"));
var EmployeeService_1 = require("./services/EmployeeService");
var EmployeeDirectoryWebPart = /** @class */ (function (_super) {
    tslib_1.__extends(EmployeeDirectoryWebPart, _super);
    function EmployeeDirectoryWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EmployeeDirectoryWebPart.prototype.render = function () {
        var element = React.createElement(EmployeeDirectory_1.default, {
            title: this.properties.title,
            showFilters: !!this.properties.showFilters,
            showSorting: !!this.properties.showSorting,
            employeeService: this._employeeService,
            peoplePickerContext: this._peoplePickerContext
        });
        ReactDom.render(element, this.domElement);
    };
    EmployeeDirectoryWebPart.prototype.onInit = function () {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var sp;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.onInit.call(this)];
                    case 1:
                        _a.sent();
                        sp = (0, sp_1.spfi)().using((0, sp_1.SPFx)(this.context));
                        this._employeeService = new EmployeeService_1.EmployeeService(sp);
                        this._peoplePickerContext = {
                            absoluteUrl: this.context.pageContext.web.absoluteUrl,
                            msGraphClientFactory: this.context.msGraphClientFactory,
                            spHttpClient: this.context.spHttpClient
                        };
                        return [2 /*return*/];
                }
            });
        });
    };
    EmployeeDirectoryWebPart.prototype.onThemeChanged = function (currentTheme) {
        if (!currentTheme) {
            return;
        }
        var semanticColors = currentTheme.semanticColors;
        if (semanticColors) {
            this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
            this.domElement.style.setProperty('--link', semanticColors.link || null);
            this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
        }
    };
    EmployeeDirectoryWebPart.prototype.onDispose = function () {
        ReactDom.unmountComponentAtNode(this.domElement);
    };
    Object.defineProperty(EmployeeDirectoryWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    EmployeeDirectoryWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                (0, sp_property_pane_1.PropertyPaneTextField)('title', {
                                    label: strings.TitleFieldLabel,
                                    description: strings.TitleFieldDescription
                                })
                            ]
                        },
                        {
                            groupName: strings.DisplayGroupName,
                            groupFields: [
                                (0, sp_property_pane_1.PropertyPaneToggle)('showFilters', {
                                    label: strings.ShowFiltersFieldLabel,
                                    onText: strings.ToggleOnText,
                                    offText: strings.ToggleOffText
                                }),
                                (0, sp_property_pane_1.PropertyPaneToggle)('showSorting', {
                                    label: strings.ShowSortingFieldLabel,
                                    onText: strings.ToggleOnText,
                                    offText: strings.ToggleOffText
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return EmployeeDirectoryWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = EmployeeDirectoryWebPart;
//# sourceMappingURL=EmployeeDirectoryWebPart.js.map