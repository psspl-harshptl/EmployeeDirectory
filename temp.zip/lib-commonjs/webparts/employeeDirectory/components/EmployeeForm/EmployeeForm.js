"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("@fluentui/react");
var PeoplePicker_1 = require("@pnp/spfx-controls-react/lib/PeoplePicker");
var strings = tslib_1.__importStar(require("EmployeeDirectoryWebPartStrings"));
var Constants_1 = require("../../constants/Constants");
var dateUtils_1 = require("../../utils/dateUtils");
var employeeValidation_1 = require("../../utils/employeeValidation");
function parseSiteUserId(person) {
    var id = Number(person === null || person === void 0 ? void 0 : person.id);
    return Number.isInteger(id) && id > 0 ? id : undefined;
}
function toFormData(employee) {
    return {
        empId: employee.empId,
        userId: employee.userId,
        userEmail: employee.userEmail,
        department: employee.department,
        designationId: employee.designationId,
        mobileNo: employee.mobileNo,
        address: employee.address,
        dob: employee.dob,
        doj: employee.doj,
        isActive: employee.isActive
    };
}
var EmployeeForm = function (_a) {
    var _b;
    var isOpen = _a.isOpen, employee = _a.employee, departmentChoices = _a.departmentChoices, positions = _a.positions, peoplePickerContext = _a.peoplePickerContext, onSubmit = _a.onSubmit, onDismiss = _a.onDismiss;
    var _c = React.useState(Constants_1.EMPTY_EMPLOYEE_FORM), formData = _c[0], setFormData = _c[1];
    var _d = React.useState({}), errors = _d[0], setErrors = _d[1];
    var _e = React.useState(false), isSaving = _e[0], setIsSaving = _e[1];
    var _f = React.useState(undefined), saveError = _f[0], setSaveError = _f[1];
    var _g = React.useState([]), peoplePickerDefaultUsers = _g[0], setPeoplePickerDefaultUsers = _g[1];
    var _h = React.useState(0), peoplePickerKey = _h[0], setPeoplePickerKey = _h[1];
    var today = React.useMemo(function () { return new Date(); }, []);
    var isEditMode = employee !== undefined;
    // Each time the panel opens, start from the selected employee (edit) or an empty form (new).
    React.useEffect(function () {
        if (!isOpen) {
            return;
        }
        setFormData(employee ? toFormData(employee) : Constants_1.EMPTY_EMPLOYEE_FORM);
        setErrors({});
        setSaveError(undefined);
        setPeoplePickerDefaultUsers((employee === null || employee === void 0 ? void 0 : employee.userEmail) ? [employee.userEmail] : []);
        setPeoplePickerKey(function (key) { return key + 1; });
    }, [isOpen, employee]);
    var departmentOptions = React.useMemo(function () { return departmentChoices.map(function (choice) { return ({ key: choice, text: choice }); }); }, [departmentChoices]);
    var designationOptions = React.useMemo(function () { return positions.map(function (position) { return ({ key: position.id, text: position.title }); }); }, [positions]);
    var updateField = function (field, value) {
        setFormData(function (previous) {
            var _a;
            return (tslib_1.__assign(tslib_1.__assign({}, previous), (_a = {}, _a[field] = value, _a)));
        });
        setErrors(function (previous) {
            var _a;
            return (tslib_1.__assign(tslib_1.__assign({}, previous), (_a = {}, _a[field] = undefined, _a)));
        });
    };
    var resetForm = function () {
        setFormData(Constants_1.EMPTY_EMPLOYEE_FORM);
        setErrors({});
        setSaveError(undefined);
        setPeoplePickerDefaultUsers([]);
        setPeoplePickerKey(function (key) { return key + 1; });
    };
    var handleCancel = function () {
        if (isSaving) {
            return;
        }
        resetForm();
        onDismiss();
    };
    var handleSubmit = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var validationErrors, _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    validationErrors = (0, employeeValidation_1.validateEmployeeForm)(formData, today);
                    if (Object.keys(validationErrors).length > 0) {
                        setErrors(validationErrors);
                        return [2 /*return*/];
                    }
                    setIsSaving(true);
                    setSaveError(undefined);
                    _b.label = 1;
                case 1:
                    _b.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, onSubmit(formData)];
                case 2:
                    _b.sent();
                    resetForm();
                    return [3 /*break*/, 5];
                case 3:
                    _a = _b.sent();
                    setSaveError(strings.SaveErrorMessage);
                    return [3 /*break*/, 5];
                case 4:
                    setIsSaving(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var onRenderFooterContent = function () { return (React.createElement(react_1.Stack, { horizontal: true, tokens: { childrenGap: 8 } },
        React.createElement(react_1.PrimaryButton, { text: isSaving ? strings.SavingButton : isEditMode ? strings.UpdateButton : strings.SubmitButton, disabled: isSaving, onClick: function () {
                handleSubmit().catch(function () { return undefined; });
            } }),
        React.createElement(react_1.DefaultButton, { text: strings.CancelButton, disabled: isSaving, onClick: handleCancel }))); };
    return (React.createElement(react_1.Panel, { isOpen: isOpen, type: react_1.PanelType.medium, headerText: isEditMode ? strings.EditEmployeeFormTitle : strings.NewEmployeeFormTitle, closeButtonAriaLabel: strings.CancelButton, onDismiss: handleCancel, onRenderFooterContent: onRenderFooterContent, isFooterAtBottom: true },
        React.createElement(react_1.Stack, { tokens: { childrenGap: 12 } },
            saveError && (React.createElement(react_1.MessageBar, { messageBarType: react_1.MessageBarType.error, isMultiline: true }, saveError)),
            React.createElement(react_1.TextField, { label: strings.FieldEmpId, required: true, maxLength: 255, value: formData.empId, errorMessage: errors.empId, disabled: isSaving, onChange: function (_, value) { return updateField('empId', value !== null && value !== void 0 ? value : ''); } }),
            React.createElement(PeoplePicker_1.PeoplePicker, { key: peoplePickerKey, context: peoplePickerContext, titleText: strings.FieldUser, personSelectionLimit: 1, principalTypes: [PeoplePicker_1.PrincipalType.User], ensureUser: true, required: true, resolveDelay: 300, defaultSelectedUsers: peoplePickerDefaultUsers, errorMessage: errors.userId, disabled: isSaving, onChange: function (people) {
                    var person = people[0];
                    setFormData(function (previous) {
                        var _a;
                        return (tslib_1.__assign(tslib_1.__assign({}, previous), { userId: parseSiteUserId(person), userEmail: (_a = person === null || person === void 0 ? void 0 : person.secondaryText) !== null && _a !== void 0 ? _a : '' }));
                    });
                    setErrors(function (previous) { return (tslib_1.__assign(tslib_1.__assign({}, previous), { userId: undefined })); });
                } }),
            React.createElement(react_1.Dropdown, { label: strings.FieldDepartment, required: true, placeholder: strings.SelectPlaceholder, options: departmentOptions, selectedKey: formData.department || null, errorMessage: errors.department, disabled: isSaving, onChange: function (_, option) { var _a; return updateField('department', String((_a = option === null || option === void 0 ? void 0 : option.key) !== null && _a !== void 0 ? _a : '')); } }),
            React.createElement(react_1.Dropdown, { label: strings.FieldDesignation, required: true, placeholder: strings.SelectPlaceholder, options: designationOptions, selectedKey: (_b = formData.designationId) !== null && _b !== void 0 ? _b : null, errorMessage: errors.designationId, disabled: isSaving, onChange: function (_, option) {
                    return updateField('designationId', option !== undefined ? Number(option.key) : undefined);
                } }),
            React.createElement(react_1.TextField, { label: strings.FieldMobileNo, required: true, inputMode: "numeric", maxLength: 10, value: formData.mobileNo, errorMessage: errors.mobileNo, disabled: isSaving, onChange: function (_, value) { return updateField('mobileNo', value !== null && value !== void 0 ? value : ''); } }),
            React.createElement(react_1.TextField, { label: strings.FieldAddress, required: true, multiline: true, rows: 3, value: formData.address, errorMessage: errors.address, disabled: isSaving, onChange: function (_, value) { return updateField('address', value !== null && value !== void 0 ? value : ''); } }),
            React.createElement(react_1.DatePicker, { label: strings.FieldDOB, placeholder: strings.DatePlaceholder, value: formData.dob, maxDate: today, formatDate: dateUtils_1.formatDate, disabled: isSaving, textField: { required: true, errorMessage: errors.dob }, onSelectDate: function (date) { return updateField('dob', date !== null && date !== void 0 ? date : undefined); } }),
            React.createElement(react_1.DatePicker, { label: strings.FieldDOJ, placeholder: strings.DatePlaceholder, value: formData.doj, minDate: formData.dob, maxDate: today, formatDate: dateUtils_1.formatDate, disabled: isSaving, textField: { required: true, errorMessage: errors.doj }, onSelectDate: function (date) { return updateField('doj', date !== null && date !== void 0 ? date : undefined); } }),
            React.createElement(react_1.Checkbox, { label: strings.FieldIsActive, checked: formData.isActive, disabled: isSaving, onChange: function (_, checked) { return updateField('isActive', !!checked); } }))));
};
exports.default = EmployeeForm;
//# sourceMappingURL=EmployeeForm.js.map