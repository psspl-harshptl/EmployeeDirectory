"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("@fluentui/react");
var strings = tslib_1.__importStar(require("EmployeeDirectoryWebPartStrings"));
var stringUtils_1 = require("../../utils/stringUtils");
var StatusConfirmDialog = function (_a) {
    var _b;
    var employee = _a.employee, isUpdating = _a.isUpdating, onConfirm = _a.onConfirm, onCancel = _a.onCancel;
    // Active employees are being deactivated, inactive ones activated.
    var willDeactivate = (_b = employee === null || employee === void 0 ? void 0 : employee.isActive) !== null && _b !== void 0 ? _b : false;
    var employeeName = employee ? employee.userTitle || employee.empId : '';
    return (React.createElement(react_1.Dialog, { hidden: employee === undefined, onDismiss: isUpdating ? undefined : onCancel, dialogContentProps: {
            type: react_1.DialogType.normal,
            title: willDeactivate ? strings.ConfirmDeactivateTitle : strings.ConfirmActivateTitle,
            subText: (0, stringUtils_1.formatString)(willDeactivate ? strings.ConfirmDeactivateMessage : strings.ConfirmActivateMessage, employeeName)
        }, modalProps: { isBlocking: true } },
        React.createElement(react_1.DialogFooter, null,
            React.createElement(react_1.PrimaryButton, { text: isUpdating ? strings.UpdatingButton : strings.ConfirmButton, disabled: isUpdating, onClick: onConfirm }),
            React.createElement(react_1.DefaultButton, { text: strings.CancelButton, disabled: isUpdating, onClick: onCancel }))));
};
exports.default = StatusConfirmDialog;
//# sourceMappingURL=StatusConfirmDialog.js.map