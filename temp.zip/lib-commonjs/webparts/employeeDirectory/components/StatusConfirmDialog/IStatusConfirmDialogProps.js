"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IStatusConfirmDialogProps.js.map