"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("@fluentui/react");
var strings = tslib_1.__importStar(require("EmployeeDirectoryWebPartStrings"));
var Constants_1 = require("../constants/Constants");
var employeeQueryUtils_1 = require("../utils/employeeQueryUtils");
var stringUtils_1 = require("../utils/stringUtils");
var EmployeeDirectory_module_scss_1 = tslib_1.__importDefault(require("./EmployeeDirectory.module.scss"));
var EmployeeFilterBar_1 = tslib_1.__importDefault(require("./EmployeeFilterBar/EmployeeFilterBar"));
var EmployeeForm_1 = tslib_1.__importDefault(require("./EmployeeForm/EmployeeForm"));
var EmployeeList_1 = tslib_1.__importDefault(require("./EmployeeList/EmployeeList"));
var StatusConfirmDialog_1 = tslib_1.__importDefault(require("./StatusConfirmDialog/StatusConfirmDialog"));
var EmployeeDirectory = function (_a) {
    var title = _a.title, showFilters = _a.showFilters, showSorting = _a.showSorting, employeeService = _a.employeeService, peoplePickerContext = _a.peoplePickerContext;
    var _b = React.useState([]), employees = _b[0], setEmployees = _b[1];
    var _c = React.useState([]), departmentChoices = _c[0], setDepartmentChoices = _c[1];
    var _d = React.useState([]), positions = _d[0], setPositions = _d[1];
    var _e = React.useState(true), isLoading = _e[0], setIsLoading = _e[1];
    var _f = React.useState(undefined), errorMessage = _f[0], setErrorMessage = _f[1];
    var _g = React.useState(undefined), formOptionsError = _g[0], setFormOptionsError = _g[1];
    var _h = React.useState(undefined), notification = _h[0], setNotification = _h[1];
    var _j = React.useState(false), isFormOpen = _j[0], setIsFormOpen = _j[1];
    var _k = React.useState(undefined), editingEmployee = _k[0], setEditingEmployee = _k[1];
    var _l = React.useState(undefined), statusChangeEmployee = _l[0], setStatusChangeEmployee = _l[1];
    var _m = React.useState(false), isUpdatingStatus = _m[0], setIsUpdatingStatus = _m[1];
    var _o = React.useState(Constants_1.DEFAULT_FILTERS), filters = _o[0], setFilters = _o[1];
    var _p = React.useState(Constants_1.DEFAULT_SORT), sort = _p[0], setSort = _p[1];
    var isMountedRef = React.useRef(true);
    React.useEffect(function () {
        return function () {
            isMountedRef.current = false;
        };
    }, []);
    var loadEmployees = React.useCallback(function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var result, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setIsLoading(true);
                    setErrorMessage(undefined);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, employeeService.getEmployees()];
                case 2:
                    result = _a.sent();
                    if (isMountedRef.current) {
                        setEmployees(result);
                    }
                    return [3 /*break*/, 5];
                case 3:
                    error_1 = _a.sent();
                    console.error('EmployeeDirectory: failed to load employees', error_1);
                    if (isMountedRef.current) {
                        setErrorMessage(strings.LoadErrorMessage);
                    }
                    return [3 /*break*/, 5];
                case 4:
                    if (isMountedRef.current) {
                        setIsLoading(false);
                    }
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); }, [employeeService]);
    React.useEffect(function () {
        loadEmployees().catch(function () { return undefined; });
    }, [loadEmployees]);
    React.useEffect(function () {
        Promise.all([employeeService.getDepartmentChoices(), employeeService.getPositions()])
            .then(function (_a) {
            var choices = _a[0], positionItems = _a[1];
            if (isMountedRef.current) {
                setDepartmentChoices(choices);
                setPositions(positionItems);
            }
        })
            .catch(function (error) {
            console.error('EmployeeDirectory: failed to load form options', error);
            if (isMountedRef.current) {
                setFormOptionsError(strings.LoadFormDataErrorMessage);
            }
        });
    }, [employeeService]);
    var openNewEmployeeForm = function () {
        setNotification(undefined);
        setEditingEmployee(undefined);
        setIsFormOpen(true);
    };
    // useCallback keeps these stable, so the grid's memoized columns are not rebuilt on every render.
    var handleEdit = React.useCallback(function (employee) {
        setNotification(undefined);
        setEditingEmployee(employee);
        setIsFormOpen(true);
    }, []);
    var handleToggleActive = React.useCallback(function (employee) {
        setNotification(undefined);
        setStatusChangeEmployee(employee);
    }, []);
    var handleSubmit = function (data) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 5, , 6]);
                    if (!editingEmployee) return [3 /*break*/, 2];
                    return [4 /*yield*/, employeeService.updateEmployee(editingEmployee.id, data)];
                case 1:
                    _a.sent();
                    return [3 /*break*/, 4];
                case 2: return [4 /*yield*/, employeeService.addEmployee(data)];
                case 3:
                    _a.sent();
                    _a.label = 4;
                case 4: return [3 /*break*/, 6];
                case 5:
                    error_2 = _a.sent();
                    console.error('EmployeeDirectory: failed to save employee', error_2);
                    throw error_2;
                case 6:
                    setIsFormOpen(false);
                    setNotification({
                        type: react_1.MessageBarType.success,
                        text: editingEmployee ? strings.UpdateSuccessMessage : strings.SaveSuccessMessage
                    });
                    return [4 /*yield*/, loadEmployees()];
                case 7:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); };
    var confirmStatusChange = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var employee, newIsActive, employeeName, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!statusChangeEmployee) {
                        return [2 /*return*/];
                    }
                    employee = statusChangeEmployee;
                    newIsActive = !employee.isActive;
                    employeeName = employee.userTitle || employee.empId;
                    setIsUpdatingStatus(true);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, employeeService.setEmployeeActive(employee.id, newIsActive)];
                case 2:
                    _a.sent();
                    if (isMountedRef.current) {
                        // Only one field changed, so update the row locally instead of reloading the whole list.
                        setEmployees(function (previous) {
                            return previous.map(function (item) { return (item.id === employee.id ? tslib_1.__assign(tslib_1.__assign({}, item), { isActive: newIsActive }) : item); });
                        });
                        setNotification({
                            type: react_1.MessageBarType.success,
                            text: (0, stringUtils_1.formatString)(newIsActive ? strings.ActivatedMessage : strings.DeactivatedMessage, employeeName)
                        });
                    }
                    return [3 /*break*/, 5];
                case 3:
                    error_3 = _a.sent();
                    console.error('EmployeeDirectory: failed to update employee status', error_3);
                    if (isMountedRef.current) {
                        setNotification({ type: react_1.MessageBarType.error, text: strings.StatusUpdateErrorMessage });
                    }
                    return [3 /*break*/, 5];
                case 4:
                    if (isMountedRef.current) {
                        setIsUpdatingStatus(false);
                        setStatusChangeEmployee(undefined);
                    }
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var effectiveFilters = showFilters ? filters : Constants_1.DEFAULT_FILTERS;
    var effectiveSort = showSorting ? sort : Constants_1.DEFAULT_SORT;
    var visibleEmployees = React.useMemo(function () { return (0, employeeQueryUtils_1.sortEmployees)((0, employeeQueryUtils_1.filterEmployees)(employees, effectiveFilters), effectiveSort); }, [employees, effectiveFilters, effectiveSort]);
    return (React.createElement("section", { className: EmployeeDirectory_module_scss_1.default.employeeDirectory },
        React.createElement(react_1.Stack, { tokens: { childrenGap: 16 } },
            React.createElement(react_1.Stack, { horizontal: true, wrap: true, horizontalAlign: "space-between", verticalAlign: "center", tokens: { childrenGap: 8 } },
                React.createElement(react_1.Text, { variant: "xLarge", as: "h2" }, title || strings.DefaultTitle),
                React.createElement(react_1.PrimaryButton, { text: strings.NewEmployeeButton, iconProps: { iconName: 'AddFriend' }, onClick: openNewEmployeeForm })),
            notification && (React.createElement(react_1.MessageBar, { messageBarType: notification.type, isMultiline: true, onDismiss: function () { return setNotification(undefined); } }, notification.text)),
            formOptionsError && (React.createElement(react_1.MessageBar, { messageBarType: react_1.MessageBarType.warning, onDismiss: function () { return setFormOptionsError(undefined); } }, formOptionsError)),
            errorMessage && (React.createElement(react_1.MessageBar, { messageBarType: react_1.MessageBarType.error, isMultiline: true }, errorMessage)),
            !errorMessage && (React.createElement(React.Fragment, null,
                showFilters && (React.createElement(EmployeeFilterBar_1.default, { filters: filters, departmentChoices: departmentChoices, onFiltersChange: setFilters })),
                !isLoading && (React.createElement(react_1.Text, { variant: "medium" }, (0, stringUtils_1.formatString)(strings.EmployeeCountFormat, visibleEmployees.length, employees.length))),
                React.createElement(EmployeeList_1.default, { employees: visibleEmployees, isLoading: isLoading, sort: effectiveSort, onSortChange: showSorting ? setSort : undefined, onEdit: handleEdit, onToggleActive: handleToggleActive }),
                !isLoading && visibleEmployees.length === 0 && (React.createElement(react_1.MessageBar, null, strings.NoEmployeesMessage))))),
        React.createElement(EmployeeForm_1.default, { isOpen: isFormOpen, employee: editingEmployee, departmentChoices: departmentChoices, positions: positions, peoplePickerContext: peoplePickerContext, onSubmit: handleSubmit, onDismiss: function () { return setIsFormOpen(false); } }),
        React.createElement(StatusConfirmDialog_1.default, { employee: statusChangeEmployee, isUpdating: isUpdatingStatus, onConfirm: function () {
                confirmStatusChange().catch(function () { return undefined; });
            }, onCancel: function () { return setStatusChangeEmployee(undefined); } })));
};
exports.default = EmployeeDirectory;
//# sourceMappingURL=EmployeeDirectory.js.map