"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("@fluentui/react");
var strings = tslib_1.__importStar(require("EmployeeDirectoryWebPartStrings"));
var dropdownStyles = { root: { width: 180 } };
var STATUS_OPTIONS = [
    { key: 'active', text: strings.StatusActive },
    { key: 'inactive', text: strings.StatusInactive },
    { key: 'all', text: strings.StatusAll }
];
var EmployeeFilterBar = function (_a) {
    var filters = _a.filters, departmentChoices = _a.departmentChoices, onFiltersChange = _a.onFiltersChange;
    var departmentOptions = React.useMemo(function () { return tslib_1.__spreadArray([
        { key: '', text: strings.AllDepartmentsOption }
    ], departmentChoices.map(function (choice) { return ({ key: choice, text: choice }); }), true); }, [departmentChoices]);
    return (React.createElement(react_1.Stack, { horizontal: true, wrap: true, tokens: { childrenGap: 12 } },
        React.createElement(react_1.Dropdown, { label: strings.DepartmentFilterLabel, options: departmentOptions, selectedKey: filters.department, styles: dropdownStyles, onChange: function (_, option) { var _a; return onFiltersChange(tslib_1.__assign(tslib_1.__assign({}, filters), { department: String((_a = option === null || option === void 0 ? void 0 : option.key) !== null && _a !== void 0 ? _a : '') })); } }),
        React.createElement(react_1.Dropdown, { label: strings.StatusFilterLabel, options: STATUS_OPTIONS, selectedKey: filters.status, styles: dropdownStyles, onChange: function (_, option) {
                return option && onFiltersChange(tslib_1.__assign(tslib_1.__assign({}, filters), { status: option.key }));
            } })));
};
exports.default = EmployeeFilterBar;
//# sourceMappingURL=EmployeeFilterBar.js.map