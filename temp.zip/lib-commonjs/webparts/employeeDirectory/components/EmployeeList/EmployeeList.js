"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("@fluentui/react");
var strings = tslib_1.__importStar(require("EmployeeDirectoryWebPartStrings"));
var dateUtils_1 = require("../../utils/dateUtils");
var getEmployeeKey = function (item, index) {
    return item ? String(item.id) : "placeholder-".concat(index);
};
var EmployeeList = function (_a) {
    var employees = _a.employees, isLoading = _a.isLoading, sort = _a.sort, onSortChange = _a.onSortChange, onEdit = _a.onEdit, onToggleActive = _a.onToggleActive;
    var columns = React.useMemo(function () {
        var sortableProps = function (field) {
            return onSortChange
                ? {
                    isSorted: sort.field === field,
                    isSortedDescending: sort.field === field && sort.isDescending,
                    onColumnClick: function () {
                        return onSortChange({ field: field, isDescending: sort.field === field ? !sort.isDescending : false });
                    }
                }
                : {};
        };
        return [
            // First column, so the buttons stay visible when the grid scrolls horizontally on narrow pages.
            {
                key: 'actions',
                name: strings.ColumnActions,
                isIconOnly: true,
                minWidth: 70,
                maxWidth: 70,
                onRender: function (item) {
                    var toggleLabel = item.isActive ? strings.DeactivateButtonLabel : strings.ActivateButtonLabel;
                    return (React.createElement(React.Fragment, null,
                        React.createElement(react_1.IconButton, { iconProps: { iconName: 'Edit' }, title: strings.EditButtonLabel, ariaLabel: "".concat(strings.EditButtonLabel, " ").concat(item.empId), onClick: function () { return onEdit(item); } }),
                        React.createElement(react_1.IconButton, { iconProps: { iconName: item.isActive ? 'UserRemove' : 'UserFollowed' }, title: toggleLabel, ariaLabel: "".concat(toggleLabel, " ").concat(item.empId), onClick: function () { return onToggleActive(item); } })));
                }
            },
            tslib_1.__assign({ key: 'empId', name: strings.ColumnEmpId, fieldName: 'empId', minWidth: 80, maxWidth: 100 }, sortableProps('empId')),
            tslib_1.__assign({ key: 'employee', name: strings.ColumnEmployee, minWidth: 160, isMultiline: true, onRender: function (item) { return (React.createElement(react_1.Persona, { text: item.userTitle, size: react_1.PersonaSize.size32 })); } }, sortableProps('userTitle')),
            tslib_1.__assign({ key: 'department', name: strings.ColumnDepartment, fieldName: 'department', minWidth: 90, maxWidth: 120 }, sortableProps('department')),
            tslib_1.__assign({ key: 'designation', name: strings.ColumnDesignation, fieldName: 'designationTitle', minWidth: 120 }, sortableProps('designationTitle')),
            { key: 'mobileNo', name: strings.ColumnMobileNo, fieldName: 'mobileNo', minWidth: 100, maxWidth: 120 },
            {
                key: 'dob',
                name: strings.ColumnDOB,
                minWidth: 90,
                maxWidth: 110,
                onRender: function (item) { return (0, dateUtils_1.formatDate)(item.dob); }
            },
            tslib_1.__assign({ key: 'doj', name: strings.ColumnDOJ, minWidth: 90, maxWidth: 110, onRender: function (item) { return (0, dateUtils_1.formatDate)(item.doj); } }, sortableProps('doj')),
            {
                key: 'age',
                name: strings.ColumnAge,
                minWidth: 40,
                maxWidth: 60,
                onRender: function (item) { var _a; return (_a = (0, dateUtils_1.getCompletedYears)(item.dob)) !== null && _a !== void 0 ? _a : ''; }
            },
            {
                key: 'joinedYears',
                name: strings.ColumnJoinedYears,
                minWidth: 80,
                maxWidth: 100,
                onRender: function (item) { var _a; return (_a = (0, dateUtils_1.getCompletedYears)(item.doj)) !== null && _a !== void 0 ? _a : ''; }
            },
            {
                key: 'status',
                name: strings.ColumnStatus,
                minWidth: 60,
                maxWidth: 80,
                onRender: function (item) { return (item.isActive ? strings.StatusActive : strings.StatusInactive); }
            }
        ];
    }, [sort, onSortChange, onEdit, onToggleActive]);
    return (React.createElement(react_1.ShimmeredDetailsList, { items: employees, columns: columns, getKey: getEmployeeKey, setKey: "employees", enableShimmer: isLoading, selectionMode: react_1.SelectionMode.none, layoutMode: react_1.DetailsListLayoutMode.justified }));
};
exports.default = EmployeeList;
//# sourceMappingURL=EmployeeList.js.map